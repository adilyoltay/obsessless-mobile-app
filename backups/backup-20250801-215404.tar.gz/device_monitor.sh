#!/bin/bash
echo "📱 iPhone Bağlantısı İzleniyor..."
while true; do
    # Check for connected devices
    devices=$(xcrun xctrace list devices | grep "Adil iphone" | grep -v "Offline")
    if [[ -n "$devices" ]]; then
        echo "🎉 Adil iPhone BAĞLANDI!"
        echo "$devices"
        break
    fi
    sleep 2
done
echo "✅ Cihaz hazır, build başlatılabilir!"
