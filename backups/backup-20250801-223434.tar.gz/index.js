import { registerRootComponent } from 'expo';
import { App } from 'expo-router/build/qualified-entry';

// Register the main component
registerRootComponent(App); 